-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Ноя 15 2020 г., 20:06
-- Версия сервера: 5.6.47
-- Версия PHP: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shoponphp`
--

-- --------------------------------------------------------

--
-- Структура таблицы `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `text` text NOT NULL,
  `data_creat` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `text`, `data_creat`) VALUES
(1, 'Alex', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus dicta dolorum eius error id ipsa nemo vitae! Autem beatae, nesciunt?', '2020-11-15 08:23:34'),
(2, 'Ivan', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet autem mollitia perferendis! Ad architecto autem consectetur deleniti dolorum earum error excepturi expedita fuga harum illo inventore ipsa laborum magnam maiores maxime mollitia natus nihil nisi odit quos reiciendis soluta sunt suscipit tenetur totam vel vero voluptas, voluptatibus, voluptatum! A adipisci amet architecto assumenda consequatur cum cupiditate dicta dolore ea eligendi eveniet, inventore iusto molestias nihil nisi non odio perspiciatis porro possimus praesentium, quae quisquam quo reiciendis, repellat rerum sapiente sit voluptate. Assumenda, eum nesciunt? Aperiam aut corporis deleniti deserunt distinctio eius error, esse, laboriosam laborum magnam, nisi numquam veniam voluptatibus.', '2020-11-15 17:05:54');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
